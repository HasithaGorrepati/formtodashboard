import React from 'react';
import FormComponent from './components/FormComponent';
import DashboardComponent from './components/DashboardComponent';

const App = () => {
  return (
    <div>
      <h1>Form to Dashboard</h1>
      <FormComponent />
      <DashboardComponent />
    </div>
  );
};

export default App;

