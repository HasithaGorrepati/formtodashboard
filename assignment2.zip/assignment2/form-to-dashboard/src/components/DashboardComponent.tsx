import React, { useEffect, useState } from 'react';

const DashboardComponent = () => {
  const [stats, setStats] = useState({ totalUsers: 0, avgAge: 0 });

  useEffect(() => {
    // Fetch data from the backend
    fetch('/api/users/stats')
      .then(res => res.json())
      .then(data => setStats(data))
      .catch(err => console.error(err));
  }, []);

  return (
    <div>
      <h2>Dashboard</h2>
      <p>Total Users: {stats.totalUsers}</p>
      <p>Average Age: {stats.avgAge}</p>
    </div>
  );
};

export default DashboardComponent;
